#!/bin/sh
# Usage : sh renommer.sh <dossier> <prefixe> [--appliquer]
# Sans --appliquer, le script affiche seulement ce qu'il ferait.
set -eu
dossier="${1:?dossier manquant}"; prefixe="${2:?prefixe manquant}"; appliquer="${3:-}"
cd "$dossier"
n=0
ls -tr | while IFS= read -r f; do
  [ -f "$f" ] || continue
  n=$((n + 1))
  ext="${f##*.}"; [ "$ext" = "$f" ] && ext="" || ext=".$ext"
  nouveau=$(printf '%s-%03d%s' "$prefixe" "$n" "$(printf '%s' "$ext" | tr 'A-Z' 'a-z')")
  [ "$f" = "$nouveau" ] && continue
  if [ -e "$nouveau" ]; then echo "existe déjà, ignoré : $nouveau"; continue; fi
  if [ "$appliquer" = "--appliquer" ]; then mv -- "$f" "$nouveau"; echo "$f -> $nouveau"; else echo "(essai) $f -> $nouveau"; fi
done
[ "$appliquer" = "--appliquer" ] || echo "Rien n'a été renommé. Relance avec --appliquer pour le faire."
