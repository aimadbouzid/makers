# Budget personnel

Chaque entrée ou sortie d’argent est une ligne. Ajoute une vue « Tableau » groupée par Catégorie, et une somme sur la colonne Montant.

## Colonnes

- **Nom**
- **Catégorie**
- **Type**
- **Montant**
- **Date**

## Conseil

Commence petit : une ligne par jour vaut mieux qu’un tableau parfait qu’on n’ouvre plus.
