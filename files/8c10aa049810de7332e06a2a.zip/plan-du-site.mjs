// Usage : node plan-du-site.mjs <dossier-du-site> <https://ton-site.com>
import fs from 'node:fs';
import path from 'node:path';

const [dossier, site] = process.argv.slice(2);
if (!dossier || !site) { console.error('Usage : node plan-du-site.mjs <dossier> <https://ton-site.com>'); process.exit(1); }
const base = site.replace(/\/$/, '');
const pages = [];
(function parcours(d) {
  for (const e of fs.readdirSync(d, { withFileTypes: true })) {
    if (e.name.startsWith('.') || e.name === 'node_modules') continue;
    const p = path.join(d, e.name);
    if (e.isDirectory()) parcours(p);
    else if (e.name.endsWith('.html') && e.name !== '404.html') {
      let rel = path.relative(dossier, p).split(path.sep).join('/');
      rel = rel === 'index.html' ? '' : rel.replace(/(^|\/)index\.html$/, '$1');
      pages.push({ loc: `${base}/${encodeURI(rel)}`, date: fs.statSync(p).mtime.toISOString().slice(0, 10) });
    }
  }
})(dossier);
const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${pages.map(p => `  <url><loc>${p.loc}</loc><lastmod>${p.date}</lastmod></url>`).join('\n')}\n</urlset>\n`;
fs.writeFileSync(path.join(dossier, 'sitemap.xml'), xml);
console.log(`${pages.length} page(s) dans ${path.join(dossier, 'sitemap.xml')}`);
