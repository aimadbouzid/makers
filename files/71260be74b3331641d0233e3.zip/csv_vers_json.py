#!/usr/bin/env python3
"""Usage : python3 csv_vers_json.py fichier.csv [sortie.json]"""
import csv, json, sys, pathlib

if len(sys.argv) < 2:
    sys.exit(__doc__)
source = pathlib.Path(sys.argv[1])
sortie = pathlib.Path(sys.argv[2]) if len(sys.argv) > 2 else source.with_suffix('.json')
texte = source.read_text(encoding='utf-8-sig')  # -sig : retire le BOM ajouté par Excel
try:
    dialecte = csv.Sniffer().sniff(texte[:4096], delimiters=',;\t')
except csv.Error:
    dialecte = csv.excel

def nombre(v):
    try:
        return int(v)
    except ValueError:
        try:
            return float(v.replace(',', '.'))
        except ValueError:
            return v

lignes = [{k.strip(): nombre(v.strip()) for k, v in l.items() if k} for l in csv.DictReader(texte.splitlines(), dialect=dialecte)]
sortie.write_text(json.dumps(lignes, ensure_ascii=False, indent=2), encoding='utf-8')
print(f'{len(lignes)} ligne(s) écrites dans {sortie}')
