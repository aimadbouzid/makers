# Suivi de candidatures

Une candidature par ligne. Statuts conseillés : À envoyer, Envoyée, Entretien, Refus, Offre. Relance au bout d’une semaine sans réponse.

## Colonnes

- **Entreprise**
- **Poste**
- **Lien de l’offre**
- **Envoyée le**
- **Statut**
- **Relance le**
- **Notes**

## Conseil

Commence petit : une ligne par jour vaut mieux qu’un tableau parfait qu’on n’ouvre plus.
