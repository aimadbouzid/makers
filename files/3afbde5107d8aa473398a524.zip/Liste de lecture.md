# Liste de lecture

Un livre par ligne. Vue « Galerie » pour les couvertures, vue « Tableau » filtrée sur Statut = À lire.

## Colonnes

- **Titre**
- **Auteur**
- **Statut**
- **Note**
- **Terminé le**
- **Ce que j’en retiens**

## Conseil

Commence petit : une ligne par jour vaut mieux qu’un tableau parfait qu’on n’ouvre plus.
